﻿using System;
using System.Collections.Generic;

#nullable disable

namespace exam.Models
{
    public partial class TeamMember
    {
        public int IdTeamMember { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string email { get; set; }

       
    }
}
